<?php
// 1. Ambil kata kunci pencarian dari URL (jika ada)
$search = isset($_GET['search']) ? mysqli_real_escape_string($koneksi, $_GET['search']) : '';

// 2. Tulis Query Dasar untuk menampilkan data (termasuk LEFT JOIN-nya)
$query = "SELECT a.*, o.nama_organisasi 
          FROM anggota a 
          LEFT JOIN organisasi o ON a.id_organisasi = o.id_organisasi";

// 3. LOGIKA MUDAH: Jika ada pencarian, sambung teks query di atas dengan WHERE
if ($search != '') {
    $query .= " WHERE a.nama_anggota LIKE '%$search%' 
                OR a.nim LIKE '%$search%' 
                OR a.prodi LIKE '%$search%' 
                OR a.jabatan LIKE '%$search%' 
                OR o.nama_organisasi LIKE '%$search%'";
}

// 4. Sambung lagi bagian akhirnya dengan ORDER BY, lalu eksekusi
$query .= " ORDER BY a.id_anggota DESC";
$result = mysqli_query($koneksi, $query);
?>