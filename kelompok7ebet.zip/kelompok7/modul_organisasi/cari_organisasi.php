<?php
// Ambil kata kunci pencarian
$search = isset($_GET['search']) ? mysqli_real_escape_string($koneksi, $_GET['search']) : '';

$query = "SELECT * FROM organisasi";

//Sambung string SQL pada saat mencari sesuatu
if ($search != '') {
    $query .= " WHERE nama_organisasi LIKE '%$search%' 
                OR ketua LIKE '%$search%'";
}

//pengurutan di akhir query
$query .= " ORDER BY id_organisasi DESC";

// 4. Eksekusi query ke database
$result = mysqli_query($koneksi, $query);
?>