<?php
// File koneksi mandiri, tidak hardcoded secara kaku
$host     = "localhost";
$username = "root";
$password = "";
$database = "db_pendataan_kegiatan_ormawa";

$koneksi = mysqli_connect($host, $username, $password, $database);

if (!$koneksi) {
    die("<div class='alert alert-danger m-3 fw-bold'>Koneksi database gagal: " . mysqli_connect_error() . "</div>");
}
?>